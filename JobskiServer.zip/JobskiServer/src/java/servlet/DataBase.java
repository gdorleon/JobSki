/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sikadie
 */
public class DataBase {

    private String urlConnexion;
    private int port;
    private String host;
    private String databaseName;
    private String login;
    private String password;
    private String pilotString;
    private String strURL = "";

    public DataBase(int port, String host, String databaseName, String login, String password, String pilotString) throws SQLException {

        this.port = port;
        this.host = host;
        this.databaseName = databaseName;
        this.login = login;
        this.password = password;
        this.pilotString = pilotString;
        try {

            Class.forName(pilotString);
            String chaine = null;
            if (pilotString.compareToIgnoreCase("com.mysql.jdbc.Driver") == 0) {
                chaine = "jdbc:mysql";
            }
            this.strURL = chaine + "://" + host + ":" + port + "/" + databaseName;
            Connection con = DriverManager.getConnection(this.strURL, login, password);
            // . . . 
            // con.close();
        } catch (ClassNotFoundException e) {
            System.err.println("Driver non chargé !");
            e.printStackTrace();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void insertData(String requete) {
        try {
            Connection con = DriverManager.getConnection(strURL, login, password);
            java.sql.Statement stmt = con.createStatement();
            int n = stmt.executeUpdate(requete);
            con.close();
            System.out.println("voici le nombre de lignes" + n);
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    public String getData(String requete) {
        String re = "";
        try {
            Connection con = DriverManager.getConnection(strURL, login, password);
            java.sql.Statement stmt = con.createStatement();

            ResultSet rs1 = stmt.executeQuery(requete);

            while (rs1.next()) {
                re = re + rs1.getString("idfeed") + ";;;" + rs1.getString("title") + ";;;" + rs1.getString("link") + ";;;"   + rs1.getString("pubDate") + ";;;" + rs1.getString("description") ;
                re = re + ":::";
            }

            con.close();
            System.out.println("voici le nombre de lignes" + re);
        } catch (SQLException e) {
  e.printStackTrace();

        }
        return re;
    }

    /**
     *
     * @param idfeed
     * @return the index with represent from where we should send data
     */
    public int getLastIndex(String idfeed) throws SQLException {
        int result = 0;
        Connection con = null;
        try {
            con = DriverManager.getConnection(strURL, login, password);

            java.sql.Statement stmt = con.createStatement();
            String requete = "SELECT * FROM feed WHERE idfeed = "+idfeed;

            ResultSet rs1 = stmt.executeQuery(requete);

            while (rs1.next()) {
                result = rs1.getInt(12);

            }

            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataBase.class.getName()).log(Level.SEVERE, null, ex);
            con.close();
        }
        return result;
    }

    public String getUrlConnexion() {
        return urlConnexion;
    }

    public void setUrlConnexion(String urlConnexion) {
        this.urlConnexion = urlConnexion;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getStrURL() {
        return strURL;
    }

    public void setStrURL(String strURL) {
        this.strURL = strURL;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPilotString() {
        return pilotString;
    }

    public void setPilotString(String pilotString) {
        this.pilotString = pilotString;
    }

}
