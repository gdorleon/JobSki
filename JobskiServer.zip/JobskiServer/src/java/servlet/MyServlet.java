/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Sikadie
 */
@WebServlet(name = "MyServlet", urlPatterns = {"/MyServlet"})
public class MyServlet extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // String urlfeed="http://jobs.bantu-media.com/?feed=rss2&post_type=job_listing";
            rechercherDocWeb("http://afd.profils.org/offre-de-emploi/flux-rss.ashx?LCID=1036&Rss_Profile=286");
            DataBase db = new DataBase(3306, "127.0.0.1", "jobski", "root", "root", "com.mysql.jdbc.Driver");
            
            TestXML testXML = new TestXML();
            db.insertData("DELETE  FROM feed");
            testXML.getAllDataNetWork();
            response.setContentType("text/html;charset=UTF-8");
            //  response.setBufferSize(8192);
            PrintWriter out = response.getWriter();

            // then write the data of the response
            out.println("<html lang=\"en\">"
                    + "<head><title>allFeeds</title></head>");
            // then write the data of the response
            String idlastfeed = request.getParameter("idlast");
            if (idlastfeed != null) {
                if (idlastfeed.compareTo("null") == 0) {
                    out.println("<body >"
                            + db.getData("SELECT * FROM freed ")
                    );
                } else {
                   // int indexSup = db.getLastIndex(idlastfeed);
                    out.println("<body >"
                            + db.getData("SELECT * FROM feed  " )
                    );

                }
            } else {
                out.println("<body >"
                        + "Nothing"
                );
            }
            //  out.println(
            //          db.getData("SELECT * FROM feed")
            //  );

            out.println("</body></html>");
            out.close();
        } catch (Exception ex) {
            Logger.getLogger(MyServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void rechercherDocWeb(String url_server) {
        URLConnection yc = null;
        try {
            URL url = null;

            url = new URL(url_server);

            yc = url.openConnection();

            String answer = "";
            String temp = "";
            FileOutputStream fOut;
            File fichier = new File("D:\\IFI\\cours IFI\\Semestre 1\\Gestion de projets\\JobskiServer\\document\\telechargement.xml");

            fOut = new FileOutputStream(fichier);
            OutputStreamWriter osw = new OutputStreamWriter(fOut);

            BufferedReader in = null;

            in = new BufferedReader(new InputStreamReader(yc.getInputStream()));

            while ((temp = in.readLine()) != null) {
                answer = answer + temp;
                osw.write(temp);

            }
            in.close();
            osw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String getServletInfo() {
        return "The Hello servlet says hello.";

    }

}
