/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Sikadie
 */
public class TestXML {

    /**
     * @param args the command line arguments
     */
    private final String filetoParse = "D:\\IFI\\cours IFI\\Semestre 1\\Gestion de projets\\JobskiServer\\document\\telechargement.xml";
    private Md5 encodeur;

    public static org.w3c.dom.Document getDoc(String file) {
        org.w3c.dom.Document doc = null;
        try {
            try {
                //permet d'éviter que les espacds ne s'affichent dans ls résultats du parsage
                javax.xml.parsers.DocumentBuilderFactory docBuilderFactory = javax.xml.parsers.DocumentBuilderFactory
                        .newInstance();
                javax.xml.parsers.DocumentBuilder docBuilder = docBuilderFactory
                        .newDocumentBuilder();
                doc = docBuilder.parse(new File(file));
                doc.getDocumentElement().normalize();
            } catch (Exception e) {
                System.out.println(e);
                e.printStackTrace();
            }
            XPathFactory xpathFactory = XPathFactory.newInstance();
// XPath to find empty text nodes.
            XPathExpression xpathExp = xpathFactory.newXPath().compile(
                    "//text()[normalize-space(.) = '']");
            NodeList emptyTextNodes = (NodeList) xpathExp.evaluate(doc, XPathConstants.NODESET);
// Remove each empty text node from document.
            for (int i = 0; i < emptyTextNodes.getLength(); i++) {
                Node emptyTextNode = emptyTextNodes.item(i);
                emptyTextNode.getParentNode().removeChild(emptyTextNode);
            }
            System.out.println("Parsing XML file" + file);

        } catch (XPathExpressionException ex) {
            Logger.getLogger(TestXML.class.getName()).log(Level.SEVERE, null, ex);
        }
        return doc;
    }

    public String getDataBase() {
        String retour = "";
        try {
            DataBase db = new DataBase(3306, "127.0.0.1", "jobski", "root", "root", "com.mysql.jdbc.Driver");
            retour = db.getData("SELECT * FROM feed");

        } catch (SQLException ex) {
            Logger.getLogger(TestXML.class.getName()).log(Level.SEVERE, null, ex);
        }

        return retour;
    }

    public TestXML() {
        super();
    }

    public void getAllDataNetWork() {
       // String filetoParse = "G:\\project\\JobskiServer\\document\\telechargement.xml";
        String xpath;
        encodeur = new Md5();
        try {
            DataBase db = new DataBase(3306, "localhost", "jobski", "root", "root", "com.mysql.jdbc.Driver");
            org.w3c.dom.Document doc = getDoc(filetoParse);
            org.w3c.dom.Node root = doc.getDocumentElement();
            System.out.println("Root element is	" + root.getNodeName());
            NodeList nl = doc.getElementsByTagName("item");
            System.out.println("Voici les choses des gars");
            for (int i = 0; i < nl.getLength(); i++) {
                NodeList elements = nl.item(i).getChildNodes();
                String[] data = new String[elements.getLength()];
                //String[] val=new String[elements.getLength()];
                for (int j = 0; j < elements.getLength(); j++) {
                    // au cameroon c 3 pour la date
                    if (j != 6) {
                        data[j] = elements.item(j).getTextContent();
                    } // String value = elements.item(j).getTextContent();
                    //System.out.println(name + " = " + value);
                    else {
                        String[] donneeDate = elements.item(j).getTextContent().split(" ");
                        String jour;
                        String moi;
                        String annee;
                        String mois = "0";
                        jour = donneeDate[1];
                        moi = donneeDate[2];
                        annee = donneeDate[3];
                        if (moi.contains("Jan")) {
                            mois = "01";
                        } else if (moi.contains("Feb")) {
                            mois = "02";
                        } else if (moi.contains("Mar")) {
                            mois = "03";
                        } else if (moi.contains("Apr")) {
                            mois = "04";
                        } else if (moi.contains("May")) {
                            mois = "05";
                        } else if (moi.contains("Jun")) {
                            mois = "06";
                        } else if (moi.contains("Jul")) {
                            mois = "07";
                        } else if (moi.contains("Aug")) {
                            mois = "08";
                        } else if (moi.contains("Sep")) {
                            mois = "09";
                        } else if (moi.contains("Oct")) {
                            mois = "10";
                        } else if (moi.contains("Nov")) {
                            mois = "11";
                        } else if (moi.contains("Dec")) {
                            mois = "12";
                        }
                        data[j] = annee + "-" + mois + "-" + jour;
                    }

                }
                data[5]=data[5].replace("'", "''");
                System.out.println("xxxx" + data[6].length());
                db.insertData("INSERT INTO feed(idfeed,title,link,comments,pubDate,dcCreator,guid,description,wfwcommentRss,slashcomment,content) VALUES (" + "\'" + encodeur.encode(data[5]) + "\'" + "," + "\'" + data[4] + "\'" + "," + "\'" + data[0] + "\'" + "," + "\'" + data[2] + "\'" + ",\'" + data[6] + "\'," + "\'" + data[4] + "\'" + "," + "\'" + data[4] + "\'" + "," + "\'" + data[5] + "\'" + "," + "\'" + data[4] + "\'" + "," + "null" + "," + "\'" + data[4] + "\'" + ")");

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return;
    }

}
